public interface manaRequirement {
    public boolean is_castable(int m);
}
