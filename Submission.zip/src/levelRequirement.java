public interface levelRequirement {
    public boolean is_equipable(int l);
}
